<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConfigElementsmenu extends Model
{
    protected $table = "config_elementsmenu";
    protected $primaryKey = "id";

    public $timestamps = false;

    protected $fillable= [
        'titulo',
        'enlace',
        'icono',
        'idmenu'        
    ];

    protected $guarded= [

    ];
}