<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConfigGeneral extends Model
{
    protected $table = "config_general";
    protected $primaryKey = "id";

    public $timestamps = false;

    protected $fillable= [
        'fuente',
        'tamaño',
        'logo',
        'fondo',
        'pestaña_titulo',
        'icono_pagina',
        'mapa',
        'idpagina'
    ];

    protected $guarded= [

    ];
}
