<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seccion2 extends Model
{
    protected $table = "seccion2";
    protected $primaryKey = "id";

    public $timestamps = false;

    protected $fillable= [
        'idpagina',
        'imagen',
        'titulo',
        'descripcion'
    ];

    protected $guarded= [

    ];
}