<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Seccion1Controller extends Controller
{
    //
}
