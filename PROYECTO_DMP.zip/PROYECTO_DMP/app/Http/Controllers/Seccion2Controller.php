<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Seccion2Controller extends Controller
{
    //
}
