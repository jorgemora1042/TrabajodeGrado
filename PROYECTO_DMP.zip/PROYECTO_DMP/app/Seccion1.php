<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seccion1 extends Model
{
    protected $table = "seccion1";
    protected $primaryKey = "id";

    public $timestamps = false;

    protected $fillable= [
        'idpagina',
        'imagen',
        'titulo',
        'descripcion'
    ];

    protected $guarded= [

    ];
}