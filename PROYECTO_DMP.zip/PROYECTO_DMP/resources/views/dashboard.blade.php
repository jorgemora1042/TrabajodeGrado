@extends('layouts.admin')
@section('contenido')
    <h1>Dashboard</h1>
@endsection