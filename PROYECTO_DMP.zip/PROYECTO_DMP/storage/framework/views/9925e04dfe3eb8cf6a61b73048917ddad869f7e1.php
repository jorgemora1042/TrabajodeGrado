<div class="modal fade" id="modal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <form method="POST" action="<?php echo e(route('destroy.plantilla', $item->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <input name="_method" type="hidden" value="DELETE">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">ELIMINAR PLANTILLA</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            Despues de eliminarla no la podra recuperar.

            ¿Esta seguro que desea eliminar esta plantilla? 
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger">ELIMINAR</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
            </div>
            </div>
        </div>
    </form>
</div>