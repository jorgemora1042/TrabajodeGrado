<?php $__env->startSection('contenido'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>