<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('index.pagina')); ?>">PAGINAS</a></li>
                <li class="breadcrumb-item active">REGISTRO DE PAGINA</li>
                                
            </ol>
            <div class="container-fluid">
                <div id="ui-view">
                    <div>
    <div class="row">
        <div class="col-lg-8">
            <form method="POST" action="<?php echo e(route('store.pagina')); ?>" role="form">
            <?php echo e(csrf_field()); ?>

            <div class="card">
                <div class="card-header">   
                    <h3> REGISTRO DE PAGINA </h3>             
                </div>
                <div class="card-body">
                    <div class="row">
                    <div class="col-lg-12 form-group">
                        <input type="text" class="form-control<?php echo e($errors->has('dominio') ? ' is-invalid' : ''); ?>" name="dominio" placeholder="Nombre de tu página:">
                        <?php if($errors->has('dominio')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <stron><?php echo e($errors->first('dominio')); ?></strong>
                                    </span>
                            <?php endif; ?>
                    </div>
                    <div class="col-lg-12 form-group">
                        <div class="row">
                            <?php $__currentLoopData = $plantillas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="card">
                                        <img src="<?php echo e(asset('portadas/'.$item->portada)); ?>" style="width:100%; height:100%">
                                        <div class="card-body">
                                            <?php echo e($item->titulo); ?>

                                        </div>                                        
                                    </div>
                                    <input type="radio" id="customRadioInline2" name="idplantilla" class="form-control" value="<?php echo e($item->id); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php if($errors->has('idplantilla')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <stron><?php echo e($errors->first('idplantilla')); ?></strong>
                                    </span>
                            <?php endif; ?>
                    </div>
                    <div class="card-header">
                        <button class="btn btn-primary" type="submit"> Guardar </button>
                    </div>
                </div>                            
            </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>