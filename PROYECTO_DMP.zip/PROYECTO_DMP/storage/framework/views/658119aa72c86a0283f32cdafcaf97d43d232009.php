<?php $__env->startSection('contenido'); ?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('index.plantilla')); ?>">LISTADO DE PLANTILLAS</a></li>
                <li class="breadcrumb-item active">ACTUALIZAR PLANTILLA</li>
                                
            </ol>
            <div class="container-fluid">
                <div id="ui-view">
                    <div>
    <div class="row">
        <div class="col-lg-6">
            <form method="POST" action="<?php echo e(route('update.plantilla', $plantilla->id)); ?>" role="form" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input name="_method" type="hidden" value="PATCH">
            <div class="card">
                <div class="card-header">   
                    <h3> ACTUALIZAR PLANTILLA </h3>             
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 form-group">
                            <input type="text" class="form-control<?php echo e($errors->has('titulo') ? ' is-invalid' : ''); ?>" placeholder="Título de Plantilla" name="titulo" value="<?php echo e($plantilla->titulo); ?>">
                            <?php if($errors->has('titulo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <stron><?php echo e($errors->first('titulo')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-12 form-group">
                            <textarea class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>" placeholder="Descripción de la plantilla" name="descripcion"><?php echo e($plantilla->descripcion); ?></textarea>
                            <?php if($errors->has('descripcion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-12 form-group">
                            <label><b>Portada de Plantilla</b></label>
                            <input type="file" class="form-control<?php echo e($errors->has('portada') ? ' is-invalid' : ''); ?>" name="portada">
                            <?php if($errors->has('portada')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('portada')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <hr>
                        <center><img src="<?php echo e(asset('portadas/'.$plantilla->portada)); ?>" style="width:80%"></center>
                    </div>
                    <div class="card-header">
                        <button class="btn btn-primary" type="submit"> Guardar </button>
                    </div>
                </div>                            
            </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>